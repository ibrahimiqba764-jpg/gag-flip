
Pet Battles Demo (Static)
------------------------

This is a safe, static demo UI for showcasing a pet inventory + match UI.
**It does NOT connect to Roblox or any real game.** Admin actions are client-side and for demonstration only.

Files:
- index.html  -> Open in a browser to run the demo.
- All data is stored in browser localStorage. To reset, clear site storage for this page.

How to use:
1. Open index.html in a browser.
2. As a user: enter a username and Connect. New users start with 0 pets and 0 balance.
3. As owner: unlock Admin using the owner password (client-side default: owner123).
   - Grant pets to users by entering their username and selecting a pet.
   - Set balances manually.
4. To "deposit" from Roblox: the app shows instructions to add user EzFlxshW in Roblox.
   - Admin must manually grant the pet after receiving it in-game. This is a manual flow only.

Caveats & Safety:
- Do NOT use this for real-money gambling or real item trading.
- For any real integration with game inventories, obtain legal advice and platform permissions.
